# -*- coding: utf-8 -*-
"""
Created on Sat Aug  4 04:59:03 2018

@author: Hassan Mahmood
"""

from csv import DictReader
from csv import DictWriter
import pandas as pd


class DataSet():
    def __init__(self,name="train", path="C:/Users/Hassan Mahmood/Desktop/Waterloo/3rd Term/Text Analytics/Project/Fnc 4/fnc last/FNC_Final_custom"):
        self.path = path
        #name='train'
        print("Reading dataset")
        bodies = name+"_bodies.csv"
        stances = name+"_stances.csv"

        self.stances = self.read(stances)
        articles = self.read(bodies)
        self.articles = dict()

        #make the body ID an integer value
        for s in self.stances:
            s['Body ID'] = int(s['Body ID'])

        #copy all bodies into a dictionary
        for article in articles:
            self.articles[int(article['Body ID'])] = article['articleBody']

        print("Total stances: " + str(len(self.stances)))
        print("Total bodies: " + str(len(self.articles)))



    def read(self,filename):
        rows = []
        with open(self.path + "/" + filename, "r", encoding='utf-8') as table:
            r = DictReader(table)

            for line in r:
                rows.append(line)
        return rows

class TestDataSet():
    def __init__(self,name="test", path="C:/Users/Hassan Mahmood/Desktop/Waterloo/3rd Term/Text Analytics/Project/Fnc 4/fnc last/FNC_Final_custom"):
        self.path = path
        #name='test'
        print("Reading test dataset")
        bodies = name+"_bodies.csv"
        stances = name+"_stances.csv"

        self.stances = self.read(stances)
        articles = self.read(bodies)
        self.articles = dict()

        #make the body ID an integer value
        for s in self.stances:
            s['Body ID'] = int(s['Body ID'])

        #copy all bodies into a dictionary
        for article in articles:
            self.articles[int(article['Body ID'])] = article['articleBody']

        print("Total stances: " + str(len(self.stances)))
        print("Total bodies: " + str(len(self.articles)))




    def read(self,filename):
        rows = []
        with open(self.path + "/" + filename, "r", encoding='utf-8') as table:
            r = DictReader(table)

            for line in r:
                rows.append(line)
        return rows

class ValidDataSet():
    def __init__(self,name="validation", path="C:/Users/Hassan Mahmood/Desktop/Waterloo/3rd Term/Text Analytics/Project/Fnc 4/fnc last/FNC_Final_custom"):
        self.path = path
        #name='test'
        print("Reading test dataset")
        bodies = name+"_bodies.csv"
        stances = name+"_stances.csv"

        self.stances = self.read(stances)
        articles = self.read(bodies)
        self.articles = dict()

        #make the body ID an integer value
        for s in self.stances:
            s['Body ID'] = int(s['Body ID'])

        #copy all bodies into a dictionary
        for article in articles:
            self.articles[int(article['Body ID'])] = article['articleBody']

        print("Total stances: " + str(len(self.stances)))
        print("Total bodies: " + str(len(self.articles)))
        
    def read(self,filename):
        rows = []
        with open(self.path + "/" + filename, "r", encoding='utf-8') as table:
            r = DictReader(table)

            for line in r:
                rows.append(line)
        return rows

LABELS = ['agree', 'disagree', 'discuss', 'unrelated']



def write_submission(test_d, predicted, filename):
    with open(filename, 'w') as csvfile:
        writer = csv.writer(csvfile, delimiter=',')
        writer.writerow(['Headline','Body ID','Stance'])
        for stance_row, label in zip(test_d.stances, predicted):
            writer.writerow([stance_row['Headline'], stance_row['Body ID'], LABELS[label]])
label_ref_rev = {0: 'agree', 1: 'disagree', 2: 'discuss', 3: 'unrelated'}

def save_predictions(pred, file):

    """

    Save predictions to CSV file

    Args:
        pred: numpy array, of numeric predictions
        file: str, filename + extension

    """

    with open(file, 'w') as csvfile:
        fieldnames = ['Stance']
        writer = DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        for instance in pred:
            writer.writerow({'Stance': label_ref_rev[instance]})